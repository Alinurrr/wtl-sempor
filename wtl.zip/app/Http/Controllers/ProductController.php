<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::latest()->paginate(40);
        return view('admin.product.index,', [
            'products' => $products,
        ]);
    }

    public function create()
    {
        return view('admin.product.create', [
            'product' => new Product()
        ]);
    }

    public function store()
    {

        //validate
        $attr = request()->validate([
            'judul' => 'required',
            'gambar' => 'required',
            'harga' => 'required|numeric',
            'desc' => 'required'
        ]);

        // input gambar
        $gambar = request()->file('gambar')->store("images/products");

        //Assign title to the slug
        $attr['slug'] = \Str::slug(request('judul'));

        $attr['gambar'] = $gambar;

        // create new
        Product::create($attr);


        return redirect()->to(route('product-admin'))->with('success', 'Product Berhasil Di Tambahkan!');
    }
}
