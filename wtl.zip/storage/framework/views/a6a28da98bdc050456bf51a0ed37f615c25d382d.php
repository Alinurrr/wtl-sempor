<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
<section class="section">
    <div class="section-header">
    <h1>Ini Halaman Dashboard</h1>
    </div>

    <div class="section-body">
    </div>
</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-adm.app-adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\wtl\resources\views/admin/index.blade.php ENDPATH**/ ?>