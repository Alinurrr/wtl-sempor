<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
<section class="section">
    <div class="section-header">
    <h1>Ini Halaman Edit Profile</h1>
    </div>

    <div class="section-body">

        <div class="col-12 col-md-12 col-lg-7">
            <div class="card">
            <form action="<?php echo e(route('user-update', $user->id )); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>
                <div class="card-header">
                  <h4>Edit Profile</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                      <div class="form-group col-md-12 col-12">
                        <label>Nama Lengkap</label>
                        <input name="name" type="text" class="form-control" value="<?php echo e(old('name') ?? $user->name); ?>" required="">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="mt-2 text-danger">
                            <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="form-group col-md-6 col-12">
                        <label>Tanggal Lahir</label>
                        <input name="tanggal_lahir" type="date" class="form-control" value="<?php echo e(date('Y-m-d', strtotime($user->tanggal_lahir))); ?>">
                      </div>
                      <div class="form-group col-md-6 col-12">
                        <label>Jenis Kelamin</label>
                        <select class="form-control selectric" name="gender">
                            <option disabled="" selected="">Pilih Satu Yuk</option>
                            <option <?php echo e($user->gender == "L" ? 'selected' : ''); ?> value="L">Laki - laki</option>
                            <option <?php echo e($user->gender == "P" ? 'selected' : ''); ?> value="P">Perempuan</option>
                            <option <?php echo e($user->gender == "O" ? 'selected' : ''); ?> value="O">Lainnya</option>
                            <option value="">Tidak ingin menyebutkan</option>
                        </select>
                      </div>
                    </div>
                    <div class="row">
                      <div class="form-group col-md-7 col-12">
                        <label>Email</label>
                        <input name="email" type="email" class="form-control" value="<?php echo e(old('email') ?? $user->email); ?>" required="">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="mt-2 text-danger">
                            <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="form-group col-md-5 col-12">
                        <label>Phone</label>
                        <input name="no_hp" type="tel" class="form-control" value="<?php echo e(old('no_hp') ?? $user->no_hp); ?>" required>
                        <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="mt-2 text-danger">
                            <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>

                </div>
                <div class="card-footer text-right">
                  <button class="btn btn-primary">Save Changes</button>
                </div>
              </form>
            </div>
          </div>

    </div>
</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-adm.app-adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\wtl\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>