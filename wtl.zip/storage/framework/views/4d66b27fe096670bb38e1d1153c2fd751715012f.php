<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
<section class="section">
    <div class="section-header">
    <h1>Ini Halaman Managemen User</h1>
    </div>

    <div class="section-body">
        <h2 class="section-title">WTL User</h2>
        <form class="form-group" action="<?php echo e(route('search-user')); ?>" method="GET">
            <div class="col-6 input-group mb-3">
                <input class="form-control" type="search" placeholder="Search" aria-label="Search" data-width="250" name="query" value="<?php echo e(old('query')); ?>">
                <button class="btn btn-info" type="submit"><i class="fas fa-search"></i></button>
            </div>
        </form>


        
        <?php if(auth()->user()->level=="master"): ?>

        <div class="row mt-4">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h4>Master</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-striped" id="table-1">
                    <thead>
                      <tr>
                        <th class="text-center">
                          #
                        </th>
                        <th>Nama</th>
                        <th>id</th>
                        <th>E-Mail</th>
                        <th>Level</th>
                        <th>Waktu Registrasi</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
                        $no = 0
                    ?>
                    <?php $__currentLoopData = $master_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $no++
                    ?>

                      <tr>
                        <td>
                          <?php echo e($no); ?>

                        </td>

                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->level); ?></td>

                        <td><?php echo e($user->created_at->format("D, d/M/Y")); ?></td>


                        <td>
                            <a href="/adm/user/<?php echo e($user->id); ?>" class="btn btn-icon btn-info"><i class="fas fa-info-circle"></i></a>
                                
                        </td>
                      </tr>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endif; ?>

        
        <div class="row mt-4">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h4>Admin</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-striped" id="table-1">
                    <thead>
                      <tr>
                        <th class="text-center">
                          #
                        </th>
                        <th>Nama</th>
                        <th>id</th>
                        <th>E-Mail</th>
                        <th>Level</th>
                        <th>Waktu Registrasi</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
                        $no = 0
                    ?>
                    <?php $__currentLoopData = $admin_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $no++
                    ?>

                      <tr>
                        <td>
                          <?php echo e($no); ?>

                        </td>

                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->level); ?></td>

                        <td><?php echo e($user->created_at->format("D, d/M/Y")); ?></td>


                        <td>
                                <a href="/adm/user/<?php echo e($user->id); ?>" class="btn btn-icon btn-info"><i class="fas fa-info-circle"></i></a>
                                
                        </td>
                      </tr>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>

        
        <div class="row mt-4">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h4>User</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-striped" id="table-1">
                    <thead>
                      <tr>
                        <th class="text-center">
                          #
                        </th>
                        <th>Nama</th>
                        <th>id</th>
                        <th>E-Mail</th>
                        <th>Level</th>
                        <th>Waktu Registrasi</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
                        $no = 0
                    ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $no++
                    ?>

                      <tr>
                        <td>
                          <?php echo e($no); ?>

                        </td>

                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->level); ?></td>

                        <td><?php echo e($user->created_at->format("D, d/M/Y")); ?></td>


                        <td>
                            <a href="<?php echo e(route('user-show', $user->id)); ?>" class="btn btn-icon btn-info"><i class="fas fa-info-circle"></i></a>
                                
                        </td>
                      </tr>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>





        </div>



    </div>
</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-adm.app-adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\wtl\resources\views/admin/user/index.blade.php ENDPATH**/ ?>