<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
<section class="section">
    <div class="section-header">
    <h1>Ini Halaman Detail User</h1>
    </div>

    <div class="section-body">
        <h2 class="section-title"><?php echo e($user->name); ?></h2>
        <p class="section-lead">
          Change information about yourself on this page.
        </p>

        <div class="row mt-sm-4">
          <div class="col-12 col-md-12 col-lg-7">
            <div class="card profile-widget">
              <div class="profile-widget-header">
                <img alt="image" src="<?php echo e(asset('stisla/img/avatar/avatar-1.png')); ?>" class="rounded-circle profile-widget-picture">
                <div class="profile-widget-items">
                  <div class="profile-widget-item">
                    <div class="profile-widget-item-label">Posts</div>
                    <div class="profile-widget-item-value">187</div>
                  </div>
                  <div class="profile-widget-item">
                    <div class="profile-widget-item-label">Followers</div>
                    <div class="profile-widget-item-value">6,8K</div>
                  </div>
                  <div class="profile-widget-item">
                    <div class="profile-widget-item-label">Following</div>
                    <div class="profile-widget-item-value">2,1K</div>
                  </div>
                </div>
              </div>
              <div class="profile-widget-description">
                <div class="profile-widget-name text-capitalize"><?php echo e($user->name); ?> <div class="text-muted d-inline font-weight-normal"><div class="slash"></div> <?php echo e($user->level); ?></div> <a href="/adm/user/<?php echo e($user->id); ?>/editlevel"><small class="text-success"> - Edit Level</small></a> </div>
                <form method="post" class="needs-validation" novalidate="">
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-md-7 col-12">
                                <label>Tanggal Lahir</label>
                                <?php if($user->gender == null): ?>
                                    <p class="text-secondary">Belum Menambhakan Tanggal Lahir</p>
                                <?php else: ?>
                                    <p><?php echo e(date('d F Y', strtotime($user->tanggal_lahir))); ?></p>
                                <?php endif; ?>
                            </div>

                            <div class="form-group col-md-5 col-12">
                                <label>Jenis Kelamin</label>
                                <?php if($user->gender == "L"): ?>
                                    <p>Laki - Laki</p>

                                <?php elseif($user->gender == "P"): ?>
                                    <p>Perempuan</p>

                                <?php elseif($user->gender == "o"): ?>
                                    <p>Lainnya</p>

                                <?php else: ?>
                                    <p class="text-secondary">Belum Menambhakan Jenis Kelamin</p>

                                <?php endif; ?>
                          </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-7 col-12">
                                <label>Email</label>
                                <p><?php echo e($user->email); ?></p>
                            </div>
                            <div class="form-group col-md-5 col-12">
                                <label>Phone</label>
                                <?php if($user->no_hp == null): ?>
                                    <p class="text-secondary">Belum Menambhakan Nomor Telephon</p>
                                <?php else: ?>
                                    <p><?php echo e($user->no_hp); ?></p>
                                <?php endif; ?>
                          </div>
                        </div>

                    </div>
                    <?php if(Auth::user()->id == ($user->id)): ?>
                        <div class="card-footer text-right">
                            <a href="<?php echo e(route('user-edit', $user->id)); ?>" class="btn btn-primary">Edit Profile</a>
                        </div>
                    <?php endif; ?>
                  </form>
              </div>

            </div>
          </div>
          
        </div>
      </div>
</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-adm.app-adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\wtl\resources\views/admin/user/show.blade.php ENDPATH**/ ?>