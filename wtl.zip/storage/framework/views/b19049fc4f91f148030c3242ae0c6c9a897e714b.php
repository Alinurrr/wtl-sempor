<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
<section class="section">
    <div class="section-header">
        <h1>Ini Halaman Artikel</h1>
    </div>

    <div class="section-body">
        <div class="row mr-3 mb-3">
            <h2 class="section-title">Article WTL</h2>
            <div class="ml-auto" style="margin: 20px 0 25px 0;">
                <a href="<?php echo e(route('article-create')); ?>" class="btn btn-icon icon-left btn-primary"><i class="far fa-edit"></i> Tambah Artikel</a>
            </div>
        </div>

        <form class="form-group" action="<?php echo e(route('search-article')); ?>" method="GET">
            <div class="col-6 input-group mb-3">
                <input class="form-control" type="search" placeholder="Search" aria-label="Search" data-width="250" name="query" value="<?php echo e(old('query')); ?>">
                <button class="btn btn-info" type="submit"><i class="fas fa-search"></i></button>
            </div>
        </form>

        <div class="row">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-12 col-md-4 col-lg-4 my-2">
              <article class="article article-style-c h-100">
                <div class="article-header">
                  <img src="/<?php echo e($article->thumbnail); ?>" alt="" style="height: 270px; object-fit: cover; object-position: center;" class="d-flex align-items-center">
                  
                </div>
                <div class="article-details">
                  <div class="article-category"><a href="#"><?php echo e($article->article_category->name); ?></a> <div class="bullet"></div> <a href="#">5 Days</a></div>
                  <div class="article-title">
                    <h2><a href="/adm/article/<?php echo e($article->slug); ?>"><?php echo e($article->title); ?></a></h2>
                  </div>
                  <p><?php echo Str::limit($article->body, 30); ?></p>

                  <div class="article-user">
                    <img alt="image" src="<?php echo e(asset('stisla/img/avatar/avatar-1.png')); ?>">
                    <div class="article-user-details">
                      <div class="user-detail-name">
                        <a href="<?php echo e(route('user-show', $article->author->id)); ?>"><?php echo e($article->author->name); ?></a>
                      </div>
                      <div class="text-job">Web Developer</div>
                    </div>
                  </div>

                </div>
              </article>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            
          </div>

    </div>
</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-adm.app-adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\wtl\resources\views/admin/article/index.blade.php ENDPATH**/ ?>