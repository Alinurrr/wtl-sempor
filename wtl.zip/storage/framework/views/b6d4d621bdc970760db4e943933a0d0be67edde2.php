<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
<section class="section">
    <div class="section-header">
    <h1>Ini Halaman Edit Level user</h1>
    </div>

    <div class="section-body">
        <div class="col-12 col-md-12 col-lg-7">
            <div class="card">
                <form action="/adm/user/<?php echo e($user->id); ?>/editlevel" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="card-header">
                  <h4>Nama : <?php echo e($user->name); ?></h4>
                </div>
                <div class="card-body">
                    <div class="row">
                      <div class="form-group ml-3 col-md-8 col-12">
                        <label>Role</label>
                        <select name="level" class="form-control">
                        <?php if(auth()->user()->level=="master"): ?>
                        <option value="master" <?php echo e($user->level == 'master' ? 'selected' : ''); ?>>Master</option>
                        <?php endif; ?>
                          <option value="admin" <?php echo e($user->level == 'admin' ? 'selected' : ''); ?>>Admin</option>
                          <option value="user" <?php echo e($user->level == 'user' ? 'selected' : ''); ?>>User</option>
                        </select>
                      </div>
                    </div>

                </div>
                <div class="card-footer text-right">
                  <button class="btn btn-primary">Save Changes</button>
                </div>
              </form>
            </div>
    </div>
</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-adm.app-adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\wtl\resources\views/admin/user/editlevel.blade.php ENDPATH**/ ?>