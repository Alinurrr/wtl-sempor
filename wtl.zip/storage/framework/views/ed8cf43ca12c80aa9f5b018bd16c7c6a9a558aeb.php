
<?php /**PATH D:\laragon\www\wtl\resources\views/layouts/nav.blade.php ENDPATH**/ ?>