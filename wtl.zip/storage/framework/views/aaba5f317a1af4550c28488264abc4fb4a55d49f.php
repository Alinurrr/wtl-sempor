<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
<section class="section">
    <div class="section-header">
    <h1>List Product</h1>
    <div class="section-header-breadcrumb">
        <div class="breadcrumb-item"><a href="<?php echo e(route('product-admin')); ?>">Product</a></div>
    </div>
    </div>


    <div class="section-body">
        <h2 class="section-title">All Product</h2>
        <div class="row my-3">

            <div>
                <p class="section-lead">
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima suscipit accusamus temporibus,
                </p>
            </div>

        </div>


        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h4>My Product</h4>
                <div class="ml-auto mr-3">
                    <a href="<?php echo e(route('product-create')); ?>" class="btn btn-icon icon-left btn-primary"><i class="far fa-edit"></i> Tambah</a>
                </div>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-striped" id="table-1">
                    <thead>
                      <tr>
                        <th class="text-center">
                          #
                        </th>
                        <th>Gambar</th>
                        <th>Judul</th>
                        <th>Harga</th>
                        <th>Waktu Upload</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
                        $no = 0
                    ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $no++
                    ?>

                      <tr>
                        <td>
                          <?php echo e($no); ?>

                        </td>

                        <td>
                          <img alt="image" src="/<?php echo e($product->thumbnail); ?>" class="img img-fluid p-2" width="200" data-toggle="tooltip" title="Mantap">
                        </td>
                        <td><?php echo e($product->judul); ?></td>

                        <td>Rp.<?php echo e($product->harga); ?></td>

                        <td><?php echo e($product->created_at->format("D, d/M/Y")); ?></td>


                        <td>
                                <a href="/adm/portfolio/<?php echo e($product->slug); ?>" class="btn btn-icon btn-info"><i class="fas fa-info-circle"></i></a>
                                <form action="/adm/portfolio/<?php echo e($product->slug); ?>/delete" method="POST" class="d-inline" onsubmit="return confirm('Yakin mau dihapus ?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("delete"); ?>

                                        <button type="submit" class="btn btn-icon btn-danger"><i class="fas fa-trash-alt"></i></i></button>
                                </form>
                        </td>
                      </tr>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>





        </div>



    </div>
</section>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-adm.app-adm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\wtl\resources\views/admin/product/index,.blade.php ENDPATH**/ ?>