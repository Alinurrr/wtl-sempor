<div>
<!-- Navbar -->
<nav class="navbar fixed-top navbar-expand-lg navbar-dark scrolling-navbar">
    <div class="container">

        <!-- Brand -->
        <a class="navbar-brand text-warning" href="<?php echo e(route('home')); ?>">
        <strong>Wahana Tirta Lestari </strong>
        </a>

        <!-- Collapse -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Links -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">

        <!-- Left -->
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Home
            </a>
            </li>
            <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('about*') ? 'active' : ''); ?>" href="#">About</a>
            </li>
            <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('product*') ? 'active' : ''); ?>" href="<?php echo e(route('product')); ?>">Produk</a>
            </li>
            <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('berita*') ? 'active' : ''); ?>" href="#">Berita</a>
            </li>
        </ul>

        <!-- Right -->
        <ul class="navbar-nav nav-flex-icons ml-2">
            <!-- Authentication Links -->
        <?php if(auth()->guard()->guest()): ?>
            <?php if(Route::has('register')): ?>
                <li class="nav-item mr-2">
                    <a href="<?php echo e(route('login')); ?>" class="nav-link border border-light rounded">
                        <?php echo e(__('Login')); ?>

                    </a>
                </li>
            <?php endif; ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('register')); ?>" class="nav-link text-white rounded">
                        <?php echo e(__('Register')); ?>

                    </a>
                </li>

            <?php else: ?>


                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle " href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <i class="fas fa-user"></i>  <?php echo e(Auth::user()->name); ?>

                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <?php if(auth()->user()->level!="user"): ?>
                            <a href="<?php echo e(route('dashboard')); ?>" class="dropdown-item">Halaman Dashboard</a>
                        <?php endif; ?>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>

                    </div>
                </li>
            <?php endif; ?>
        </ul>

        </div>

    </div>
</nav>
<!-- Navbar -->

</div>
<?php /**PATH D:\laragon\www\wtl\resources\views/livewire/navbar.blade.php ENDPATH**/ ?>