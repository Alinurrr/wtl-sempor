<div class="main-sidebar">
    <aside id="sidebar-wrapper">
      <div class="sidebar-brand">
        <a href="index.html">Wahana Tirta Lestari</a>
      </div>
      <div class="sidebar-brand sidebar-brand-sm">
        <a href="index.html">WTL</a>
      </div>
      <ul class="sidebar-menu">

          <li class="menu-header">Admin WTL</li>
          <li class="<?php echo e(request()->is('adm') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-paper-plane"></i> <span>Dashboard</span></a></li>
          <li class="<?php echo e(request()->is('adm/product*') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('product-admin')); ?>"><i class="fas fa-swatchbook"></i> <span>Produk</span></a></li>
          <li class="<?php echo e(request()->is('adm/article*') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('article-admin')); ?>"><i class="far fa-file-alt"></i> <span>Artikel</span></a></li>
          

        </ul>

        <div class="mt-4 mb-4 p-3 hide-sidebar-mini">
          <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-lg btn-block btn-icon-split">
            <i class="fas fa-rocket"></i> Go to main website
          </a>
        </div>
    </aside>
  </div>
<?php /**PATH D:\laragon\www\wtl\resources\views/layouts-adm/sidebar.blade.php ENDPATH**/ ?>