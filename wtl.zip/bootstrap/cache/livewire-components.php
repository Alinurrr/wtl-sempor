<?php return array (
  'home' => 'App\\Http\\Livewire\\Home',
  'navbar' => 'App\\Http\\Livewire\\Navbar',
  'product-category' => 'App\\Http\\Livewire\\ProductCategory',
  'product-detail' => 'App\\Http\\Livewire\\ProductDetail',
  'product-index' => 'App\\Http\\Livewire\\ProductIndex',
);