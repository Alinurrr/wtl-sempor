@extends('layouts-adm.app-adm')


@section('content')
<!-- Main Content -->
<div class="main-content">
<section class="section">
    <div class="section-header">
    <h1>Ini Halaman Dashboard</h1>
    </div>

    <div class="section-body">
    </div>
</section>
</div>
@endsection
